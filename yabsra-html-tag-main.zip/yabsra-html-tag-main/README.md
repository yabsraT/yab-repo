# yabsra-html-tag
Yabsra tegegne  ID 045-bsc-b1/19
what i have learnd today was i knew the main keywords like body ,html and that if we right </html> after this our code 
will not be visibel i learnd how to creat table ,headers ,list ,link ,index how to opreat them and what codes to use
when we need them and i learned about font size, colour so sfar i have learn =d this codes